// Monitor.js
export default () => {
  return <h1>Monitor Page</h1>
};