// Analysis.js
export default () => {
   return <h1>Analysis Page</h1>
}