// Workplace.js
export default () => {
  return <h1>Workplace Page</h1>
};